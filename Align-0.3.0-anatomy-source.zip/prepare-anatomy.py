"""Merge the attributed Z-Anatomy meshes into mobile-friendly display groups.
No anatomical geometry is invented. Meshes are transformed to the atlas world
coordinate system; fascia/bursae are omitted for clarity. Output CC BY-SA 4.0. Requires numpy, DracoPy and fast-simplification; fetches
original inputs from the attributed public repository if missing.
"""
import sys,struct,json,pathlib,collections,os,urllib.request
sys.path.insert(0,'/workspace/scratch/anatomy-tools')
import DracoPy,numpy as np
import fast_simplification
ROOT=(pathlib.Path(__file__).resolve().parents[1]/'dist/anatomy') if pathlib.Path(__file__).parent.name=='scripts' else pathlib.Path(__file__).resolve().parent/'anatomy'
INPUT=pathlib.Path(os.environ.get('ALIGN_ANATOMY_INPUT','/tmp/align-anatomy-upstream'));INPUT.mkdir(parents=True,exist_ok=True)
for name in ['muscular','skeletal','nervous']:
 p=INPUT/(name+'.glb')
 if not p.exists():p.write_bytes(urllib.request.urlopen('https://raw.githubusercontent.com/nqwrc/3d-anatomy/master/public/models/'+name+'.glb',timeout=60).read())
groups=collections.defaultdict(list);originals={};total=0
labels=[('gluteus maximus','Gluteus maximus'),('gluteus medius','Gluteus medius'),('gluteus minimus','Gluteus minimus'),('psoas','Iliopsoas'),('iliacus','Iliopsoas'),('rectus abdominis','Abdominals'),('oblique','Abdominals'),('transversus abdominis','Abdominals'),('biceps femoris','Hamstrings'),('semitendinosus','Hamstrings'),('semimembranosus','Hamstrings'),('gastrocnemius','Calf muscles'),('soleus','Calf muscles'),('rectus femoris','Quadriceps'),('vastus','Quadriceps'),('piriformis','Deep hip rotators'),('erector','Back extensors'),('iliocostalis','Back extensors'),('longissimus','Back extensors'),('multifidus','Back extensors'),('spinalis','Back extensors'),('deltoid','Shoulder muscles'),('pectoralis','Chest muscles'),('trapezius','Upper back muscles'),('latissimus','Upper back muscles')]
def matrix(n):
 x,y,z,w=n.get('rotation',[0,0,0,1]);R=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]],dtype=float);M=np.eye(4);M[:3,:3]=R@np.diag(n.get('scale',[1,1,1]));M[:3,3]=n.get('translation',[0,0,0]);return np.array(n['matrix']).reshape(4,4).T if 'matrix' in n else M
for system in ['muscular','skeletal','nervous']:
 b=(INPUT/(system+'.glb')).read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);blob=b[28+n:];parents={c:i for i,node in enumerate(d['nodes']) for c in node.get('children',[])};world={};decoded={}
 def transform(i):
  if i not in world:world[i]=transform(parents[i])@matrix(d['nodes'][i]) if i in parents else matrix(d['nodes'][i])
  return world[i]
 for i,node in enumerate(d['nodes']):
  if 'mesh' not in node:continue
  name=node['name'];low=name.lower()
  if system=='muscular' and (any(t in low for t in ['fascia','bursa','sheath','retinaculum','septum','ligament','aponeurosis','tract']) or not any(t in low for t in ['muscle','psoas','iliacus','triceps','biceps','oblique','erector','multifidus','spinalis','longissimus','iliocostalis','gastrocnemius','soleus'])):continue
  group='Other muscles' if system=='muscular' else 'Skeleton' if system=='skeletal' else 'Other nerves'
  if system=='muscular':group=next((label for pattern,label in labels if pattern in low),group)
  if system=='nervous' and any(t in low for t in ['sciatic nerve','tibial nerve','common fibular nerve']):group='Sciatic nerve and branches'
  if system=='nervous' and group=='Other nerves' and not any(t in low for t in ['lumbar','sacral','spinal cord','cauda','nerve']):continue
  key=system+':'+group;originals.setdefault(key,[]).append(name)
  mtx=transform(i)
  for j,primitive in enumerate(d['meshes'][node['mesh']]['primitives']):
   cachekey=(node['mesh'],j)
   if cachekey not in decoded:
    ext=primitive['extensions']['KHR_draco_mesh_compression'];v=d['bufferViews'][ext['bufferView']];a=v.get('byteOffset',0);mesh=DracoPy.decode(blob[a:a+v['byteLength']]);decoded[cachekey]=(mesh.points,mesh.faces,mesh.normals)
   pts,faces,norm=decoded[cachekey];pts=pts@mtx[:3,:3].T+mtx[:3,3];norm=norm@np.linalg.inv(mtx[:3,:3]) if norm is not None else None
   if norm is not None:norm=norm/np.maximum(np.linalg.norm(norm,axis=1,keepdims=True),1e-8)
   f=faces[:,::-1] if np.linalg.det(mtx[:3,:3])<0 else faces
   groups[key].append((pts,f,norm));total+=len(pts)
 print(system,'ready',flush=True)
# Encode grouped Draco; use its actual attribute IDs, not assumed IDs.
accessors=[];views=[];meshes=[];nodes=[];binary=bytearray();materials=[]
for key,parts in groups.items():
 pts=[];faces=[];norm=[];offset=0
 for p,f,n in parts:pts.append(p);faces.append(f+offset);norm.append(n);offset+=len(p)
 pts=np.concatenate(pts).astype(np.float32);faces=np.concatenate(faces).astype(np.uint32);norm=np.concatenate(norm).astype(np.float64)
 if len(faces)>16000:
  pts,faces=fast_simplification.simplify(pts,faces,target_reduction=.65)
  # Recompute vertex normals after simplification.
  tri=pts[faces];face_norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);norm=np.zeros_like(pts)
  for corner in range(3):np.add.at(norm,faces[:,corner],face_norm)
  norm/=np.maximum(np.linalg.norm(norm,axis=1,keepdims=True),1e-8)
 encoded=DracoPy.encode(pts,faces,quantization_bits=14,compression_level=7,normals=norm,normal_quantization_bits=10)
 read=DracoPy.decode(encoded);attr={('POSITION' if a['attribute_type']==0 else 'NORMAL'):a['unique_id'] for a in read.attributes if a['attribute_type'] in [0,1]}
 while len(binary)%4:binary.append(0)
 bv=len(views);views.append({'buffer':0,'byteOffset':len(binary),'byteLength':len(encoded)});binary.extend(encoded)
 pos=len(accessors);accessors.append({'componentType':5126,'count':len(read.points),'type':'VEC3','min':read.points.min(axis=0).tolist(),'max':read.points.max(axis=0).tolist()});normal=len(accessors);accessors.append({'componentType':5126,'count':len(read.points),'type':'VEC3'});ind=len(accessors);accessors.append({'componentType':5125,'count':read.faces.size,'type':'SCALAR'})
 system,label=key.split(':');color=[.57,.22,.20,1] if system=='muscular' else [.88,.85,.73,1] if system=='skeletal' else [1,.73,.12,1]
 mat=len(materials);materials.append({'name':label,'pbrMetallicRoughness':{'baseColorFactor':color,'roughnessFactor':.74,'metallicFactor':0},'doubleSided':True})
 meshes.append({'name':label,'primitives':[{'attributes':{'POSITION':pos,'NORMAL':normal},'indices':ind,'material':mat,'extensions':{'KHR_draco_mesh_compression':{'bufferView':bv,'attributes':attr}}}]});nodes.append({'mesh':len(meshes)-1,'name':label,'extras':{'system':system,'label':label}})
 print(label,len(pts),len(encoded),flush=True)
while len(binary)%4:binary.append(0)
d={'asset':{'version':'2.0','generator':'Align mobile grouping, Z-Anatomy / BodyParts3D; CC BY-SA 4.0'},'extensionsUsed':['KHR_draco_mesh_compression'],'extensionsRequired':['KHR_draco_mesh_compression'],'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,'materials':materials,'accessors':accessors,'bufferViews':views,'buffers':[{'byteLength':len(binary)}]}
js=json.dumps(d,separators=(',',':')).encode();js+=b' '*((-len(js))%4);out=struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary
(ROOT/'align-atlas.glb').write_bytes(out);(ROOT/'structure-groups.json').write_text(json.dumps(originals,indent=2));print('Wrote',len(out),'bytes;',total,'vertices;',len(groups),'draw groups')
