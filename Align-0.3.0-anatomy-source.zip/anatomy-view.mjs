import * as THREE from './vendor/three/three.module.js';
import {GLTFLoader} from './vendor/three/GLTFLoader.js';
import {DRACOLoader} from './vendor/three/DRACOLoader.js';
import {OrbitControls} from './vendor/three/OrbitControls.js';
import {BONES,vertexWeights,poseFor} from './anatomy-rig.mjs';
import {applyPoseRotations} from './anatomy-skeleton.mjs';
let atlasPromise=null;
function loadAtlas(){if(!atlasPromise){const draco=new DRACOLoader();draco.setDecoderPath(new URL('./vendor/three/draco/',import.meta.url).href);draco.setWorkerLimit(1);const loader=new GLTFLoader();loader.setDRACOLoader(draco);atlasPromise=loader.loadAsync(new URL('./anatomy/align-atlas.glb',import.meta.url).href).then(g=>{draco.dispose();return g;}).catch(e=>{atlasPromise=null;draco.dispose();throw e;});}return atlasPromise;}
const COLORS={muscular:0x985d58,skeletal:0xe1dfcb,nervous:0xf2c44c,target:0xa8ed7b,secondary:0xd3ae6e};
export class AnatomyView{
 constructor(host,exercise,onPick=()=>{}){this.host=host;this.exercise=exercise;this.onPick=onPick;this.live=true;this.phase=0;this.side=0;this.playing=true;this.speed=1;this.external=false;this.started=performance.now();this.meshes=[];this.materials=[];this.layers={muscular:true,skeletal:true,nervous:false};this.frame=0;this.lastPaint=0;this.init();}
 async init(){
  try{
   this.host.innerHTML='<div class="anatomy-loading"><span>◌</span><b>Loading anatomical model…</b><small>Muscles, bones and nerves · bundled on device</small></div>';
   const atlas=await loadAtlas();if(!this.live)return;
   this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'low-power'});this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));this.renderer.setClearColor(0x1b2a2a);this.renderer.outputColorSpace=THREE.SRGBColorSpace;
   this.host.innerHTML='';this.host.append(this.renderer.domElement);this.renderer.domElement.setAttribute('aria-label','Interactive three-dimensional anatomical demonstration. Drag to rotate; pinch to zoom.');this.renderer.domElement.setAttribute('role','img');
   this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(35,1,.01,30);this.camera.position.set(2.2,1.25,2.8);this.controls=new OrbitControls(this.camera,this.renderer.domElement);this.controls.target.set(0,.85,0);this.controls.enableDamping=true;this.controls.minDistance=.65;this.controls.maxDistance=6;this.controls.maxPolarAngle=Math.PI*.95;
   this.scene.add(new THREE.HemisphereLight(0xf2f6ec,0x4c5153,2.5));const key=new THREE.DirectionalLight(0xfff3dd,3);key.position.set(2,4,3);this.scene.add(key);const rim=new THREE.DirectionalLight(0x9fcbcc,1.8);rim.position.set(-3,2,-2);this.scene.add(rim);
   const grid=new THREE.GridHelper(5,30,0x63706c,0x34453f);grid.position.y=-.025;this.scene.add(grid);
   this.poseRoot=new THREE.Group();this.scene.add(this.poseRoot);this.body=new THREE.Group();this.poseRoot.add(this.body);
   this.bones=BONES.map(def=>{const b=new THREE.Bone();b.name=def.id;const parent=BONES.find(p=>p.id===def.parent);b.position.fromArray(def.p).sub(parent?new THREE.Vector3(...parent.p):new THREE.Vector3());return b;});
   BONES.forEach((def,i)=>{if(def.parent)this.bones[BONES.findIndex(p=>p.id===def.parent)].add(this.bones[i]);else this.body.add(this.bones[i]);});this.skeleton=new THREE.Skeleton(this.bones);this.body.updateMatrixWorld(true);
   atlas.scene.traverse(source=>{if(!source.isMesh)return;const geometry=source.geometry;let indices=geometry.getAttribute('skinIndex'),weights=geometry.getAttribute('skinWeight');
    if(!indices){const positions=geometry.getAttribute('position'),si=new Uint16Array(positions.count*4),sw=new Float32Array(positions.count*4);for(let i=0;i<positions.count;i++){const value=vertexWeights(positions.getX(i),positions.getY(i),positions.getZ(i));si.set(value.indices,i*4);sw.set(value.weights,i*4);}geometry.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(si,4));geometry.setAttribute('skinWeight',new THREE.Float32BufferAttribute(sw,4));}
    const system=source.userData.system||'muscular',label=source.userData.label||source.name;const material=new THREE.MeshStandardMaterial({color:COLORS[system],roughness:.7,metalness:0,side:THREE.DoubleSide});const mesh=new THREE.SkinnedMesh(geometry,material);mesh.name=label;mesh.userData={system,label};mesh.frustumCulled=false;this.body.add(mesh);
    // Geometry is in atlas/world coordinates; bind in identity space, avoiding presentation transforms.
    mesh.bind(this.skeleton,new THREE.Matrix4());this.meshes.push(mesh);this.materials.push(material);
   });
   this.skeleton.calculateInverses();this.body.position.y=-.87;this.resize=()=>{if(!this.live||!this.renderer)return;const w=this.host.clientWidth,h=this.host.clientHeight;this.renderer.setSize(w,h,false);this.camera.aspect=w/Math.max(1,h);this.camera.updateProjectionMatrix();};this.observer=new ResizeObserver(this.resize);this.observer.observe(this.host);this.resize();
   this.raycaster=new THREE.Raycaster();this.down=null;this.renderer.domElement.addEventListener('pointerdown',e=>{this.down=[e.clientX,e.clientY];});this.renderer.domElement.addEventListener('pointerup',e=>{if(!this.down||Math.hypot(e.clientX-this.down[0],e.clientY-this.down[1])>7)return;const rect=this.renderer.domElement.getBoundingClientRect();this.raycaster.setFromCamera(new THREE.Vector2((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1),this.camera);const hit=this.raycaster.intersectObjects(this.meshes.filter(m=>m.visible))[0];if(hit)this.onPick(hit.object.userData.label,hit.object.userData.system);});
   this.addProps();this.updateMaterials();this.resetCamera();this.animate(performance.now());
  }catch(e){if(!this.live)return;console.error('Anatomy viewer',e);this.host.innerHTML='<div class="anatomy-loading"><b>3D viewer could not start</b><small>Update Android System WebView or use a current Chrome browser. The exercise instructions below remain available.</small></div>';}
 }
 addProps(){const m=new THREE.MeshStandardMaterial({color:0x647469,roughness:.9,transparent:true,opacity:.6});this.materials.push(m);const box=(w,h,d,x,y,z)=>{const g=new THREE.BoxGeometry(w,h,d),mesh=new THREE.Mesh(g,m);mesh.position.set(x,y,z);this.scene.add(mesh);(this.props??=[]).push(mesh);};if(this.exercise.motion==='slider'){box(.48,.04,.44,0,.43,.03);for(const x of [-.2,.2])for(const z of [-.15,.21])box(.025,.43,.025,x,.21,z);box(.46,.4,.025,0,.67,-.19);}if(['calf','calfStretch'].includes(this.exercise.motion)){box(.65,.035,.04,0,1.02,.4);for(const x of [-.3,.3])box(.025,1.02,.025,x,.51,.4);}if(['bridge','tilt','brace','bird','abduction','clam','flexor'].includes(this.exercise.motion))box(.95,.015,2.2,0,-.018,0);}
 updateMaterials(){if(!this.exercise)return;for(const m of this.meshes){const system=m.userData.system,isTarget=this.exercise.targets.includes(m.name),secondary=this.exercise.secondary.includes(m.name);m.visible=!!this.layers[system];m.material.color.setHex(isTarget?COLORS.target:secondary?COLORS.secondary:COLORS[system]);m.material.emissive.setHex(isTarget?0x183e0b:0x000000);m.material.emissiveIntensity=isTarget?.3:0;m.material.transparent=system==='muscular';m.material.opacity=system==='muscular'?(isTarget||secondary?1:.45):1;m.material.depthWrite=system!=='muscular'||isTarget||secondary;m.renderOrder=system==='nervous'?3:system==='muscular'?2:1;}}
 setExercise(e){this.exercise=e;this.phase=0;this.external=false;this.playing=true;this.started=performance.now();this.layers.nervous=e.kind==='nerve';this.updateMaterials();this.resetCamera();}
 setLayer(name,value){this.layers[name]=value;this.updateMaterials();}
 setPhase(p,side=this.side){this.phase=Math.max(0,Math.min(1,p));this.side=side;this.external=true;}
 setPlaying(value){this.playing=value;this.external=false;this.started=performance.now();}
 setSide(side){this.side=side;}
 resetCamera(view='three-quarter'){if(!this.camera)return;const floor=!this.atlasMode&&['tilt','brace','bridge','bird','abduction','clam'].includes(this.exercise.motion),y=floor?.25:.85;this.controls.target.set(0,y,0);const pos=view==='front'?[0,y+.15,2.5]:view==='back'?[0,y+.15,-2.5]:view==='side'?[2.6,y+.2,.05]:floor?[1.7,1.3,1.9]:[2,y+.3,2.4];this.camera.position.fromArray(pos);this.controls.update();}
 animate(t){if(!this.live)return;this.frame=requestAnimationFrame(now=>this.animate(now));if(t-this.lastPaint<33||document.hidden)return;this.lastPaint=t;if(!this.external&&this.playing){const q=((t-this.started)*this.speed/6500)%1;this.phase=q<.3?q/.3:q<.65?1:1-(q-.65)/.35;}
  const pose=poseFor(this.atlasMode?'standing':this.exercise.motion,this.phase,this.side);this.poseRoot.position.fromArray(pose.root);this.poseRoot.rotation.set(...pose.rotation);applyPoseRotations(this.bones,pose);this.controls.update();this.scene.updateMatrixWorld(true);this.skeleton.update();this.renderer.render(this.scene,this.camera);
 }
 dispose(){this.live=false;cancelAnimationFrame(this.frame);this.observer?.disconnect();this.controls?.dispose();this.materials.forEach(m=>m.dispose());this.props?.forEach(m=>m.geometry.dispose());this.skeleton?.dispose();this.renderer?.dispose();this.renderer?.forceContextLoss();}
}
