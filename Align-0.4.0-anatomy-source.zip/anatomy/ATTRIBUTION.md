# Anatomical assets and adaptations

BodyParts3D © The Database Center for Life Science — CC BY-SA 2.1 Japan.
Z-Anatomy — the open source atlas of anatomy, by Gauthier Kervyn and contributors — CC BY-SA 4.0.
Redistribution source: https://github.com/nqwrc/3d-anatomy/tree/master/public/models
Upstream: https://github.com/Z-Anatomy/Models-of-human-anatomy
Original license notice: [License.txt](License.txt).
CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/
CC BY-SA 2.1 Japan: https://creativecommons.org/licenses/by-sa/2.1/jp/

Align adaptations: transforms baked to a common coordinate system, selected muscle structures grouped, fascia/bursae omitted for clarity, lower-body nerve pathways selected, mobile mesh simplification, changed display materials and target highlighting, generated exercise preview renders, approximate educational skeletal animation and joint weights. These adapted model assets and model adaptations are provided under CC BY-SA 4.0, retaining the upstream notices. No medical validation of the animation is claimed.

[Download adapted model](align-atlas.glb) · [Structure group map](structure-groups.json)
The original models remain available at the upstream links. The executable preparation script is supplied at /prepare-anatomy.py and the deformation/pose code at /anatomy-view.mjs and /anatomy-rig.mjs.

Three.js © its authors — MIT, see ../vendor/three/LICENSE. Draco © Google, Apache-2.0 (see ../vendor/three/draco/NOTICE.txt).

The user-supplied TikTok/Instagram videos were used as design references and are not redistributed. No commercial atlas or video was copied into this app.

Align 0.4 adaptation: increased mesh retention (25% triangle reduction for large groups), 16-bit positional and 12-bit normal quantization, separate biceps/triceps groups, body-area browsing, general gym movement illustrations, viewport-aware framing and selectable rendering resolution. No clinical validation is implied by increased visual resolution.
