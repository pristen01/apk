// Approximate educational posing of the attributed atlas; not a biomechanical simulation.
export const BONES=[
 {id:'pelvis',parent:null,p:[0,.87,-.03]}, {id:'spine',parent:'pelvis',p:[0,1.08,-.02]}, {id:'neck',parent:'spine',p:[0,1.46,0]},
 {id:'lHip',parent:'pelvis',p:[.08,.86,-.03]}, {id:'lKnee',parent:'lHip',p:[.085,.445,-.025]}, {id:'lAnkle',parent:'lKnee',p:[.075,.085,-.04]},
 {id:'rHip',parent:'pelvis',p:[-.08,.86,-.03]}, {id:'rKnee',parent:'rHip',p:[-.085,.445,-.025]}, {id:'rAnkle',parent:'rKnee',p:[-.075,.085,-.04]},
 {id:'lShoulder',parent:'spine',p:[.17,1.37,-.025]}, {id:'lElbow',parent:'lShoulder',p:[.215,1.1,-.025]}, {id:'lWrist',parent:'lElbow',p:[.27,.84,.01]},
 {id:'rShoulder',parent:'spine',p:[-.17,1.37,-.025]}, {id:'rElbow',parent:'rShoulder',p:[-.215,1.1,-.025]}, {id:'rWrist',parent:'rElbow',p:[-.27,.84,.01]}
];
const idx=id=>BONES.findIndex(b=>b.id===id),clamp=x=>Math.max(0,Math.min(1,x));
export function vertexWeights(x,y,z){const side=x>=0?'l':'r';let a,b,w;
 if(Math.abs(x)>(.16+(1.35-y)*.08)&&y>.69&&y<1.43){if(y<.88){a=side+'Wrist';b=side+'Elbow';w=clamp((y-.8)/.12);}else{a=side+'Elbow';b=side+'Shoulder';w=clamp((y-1.04)/.12);}}
 else if(y<.91){if(y<.14){a=side+'Ankle';b=side+'Knee';w=clamp((y-.07)/.1);}else if(y<.53){a=side+'Knee';b=side+'Hip';w=clamp((y-.4)/.1);}else{a=side+'Hip';b='pelvis';w=clamp((y-.78)/.13);}}
 else if(y>1.4){a='spine';b='neck';w=clamp((y-1.4)/.1);}else{a='pelvis';b='spine';w=clamp((y-.93)/.2);}
 return {indices:[idx(a),idx(b),0,0],weights:[1-w,w,0,0]};}
const rad=d=>d*Math.PI/180;
export function poseFor(motion,phase=0,side=0){const p=clamp(phase),a=side===0?'l':'r',b=side===0?'r':'l',r={};const put=(id,x=0,y=0,z=0)=>{r[id]=[rad(x),rad(y),rad(z)];};let root=[0,.87,0],rotation=[0,0,0],legTargets=[];
 if(['tilt','brace','bridge'].includes(motion)){
  rotation=[-Math.PI/2,0,0];root=[0,.13+(motion==='bridge'?.14*p:0),0];
  put('lHip',-50+(motion==='bridge'?22*p:0));put('rHip',-50+(motion==='bridge'?22*p:0));put('lKnee',95-20*(motion==='bridge'?p:0));put('rKnee',95-20*(motion==='bridge'?p:0));put('lAnkle',45);put('rAnkle',45);
  if(motion==='tilt'){put('pelvis',6*p);put('spine',-6*p);put('lHip',-50-6*p);put('rHip',-50-6*p);}if(motion==='bridge'){put('spine',-20*p);put('neck',20*p);}
 }
 if(motion==='bird'){rotation=[rad(75),0,0];root=[0,.44,0];put(a+'Shoulder',-75-90*p);put(b+'Shoulder',-75);put(a+'Hip',-75);put(a+'Knee',75);put(b+'Hip',-75+90*p);put(b+'Knee',75*(1-p));put('lAnkle',90);put('rAnkle',90);put(a+'Wrist',-90*(1-p));put(b+'Wrist',-90);}
 if(['abduction','clam'].includes(motion)){rotation=[0,0,side===0?Math.PI/2:-Math.PI/2];root=[0,.17,0];const sign=side===0?1:-1;if(motion==='abduction'){put(a+'Hip',0,0,sign*25*p);put(b+'Hip',-25);put(b+'Knee',55);}else{legTargets=clamTargets(side,p);}put('lShoulder',-15,0,-25);put('rShoulder',-15,0,25);}
 if(motion==='flexor'){root=[0,.5,.04*p];put(a+'Hip',-80);put(a+'Knee',80);put(a+'Ankle',0);put(b+'Hip',-4*p);put(b+'Knee',85);put(b+'Ankle',95);put('lShoulder',-35);put('rShoulder',-35);put('lElbow',-30);put('rElbow',-30);}
 if(motion==='calf'){root=[0,.87+.045*p,0];put('lAnkle',-14*p);put('rAnkle',-14*p);put('lShoulder',-45);put('rShoulder',-45);}
 if(motion==='calfStretch'){root=[0,.83,.025*p];put(a+'Hip',-20);put(a+'Knee',25);put(a+'Ankle',-5);put(b+'Hip',18);put(b+'Knee',0);put(b+'Ankle',-18);put('lShoulder',-65);put('rShoulder',-65);}
 if(motion==='slider'){root=[0,.48,0];put('lHip',-90);put('rHip',-90);put('lKnee',90);put('rKnee',90);put(a+'Knee',90-65*p);put(a+'Ankle',25*p);put('neck',8-15*p);put('lShoulder',-15,0,-25);put('rShoulder',-15,0,25);}
 if(motion==='squat'){root=[0,.87-.16*p,-.06*p];put('spine',12*p);for(const s of ['l','r']){put(s+'Hip',-35*p);put(s+'Knee',60*p);put(s+'Ankle',-25*p);put(s+'Shoulder',-70);}}
 if(motion==='curl'){for(const s of ['l','r'])put(s+'Elbow',-100*p);}
 if(motion==='raise'){put('lShoulder',0,0,65*p);put('rShoulder',0,0,-65*p);put('lElbow',-10);put('rElbow',-10);}
 if(motion==='row'){for(const s of ['l','r']){put(s+'Hip',-90);put(s+'Knee',90);put(s+'Shoulder',-80+65*p);put(s+'Elbow',-85*p);}root=[0,.48,0];}
 if(motion==='wallPress'){root=[0,.87,.04*p];put('spine',6*p);for(const s of ['l','r']){put(s+'Shoulder',-90+30*p);put(s+'Elbow',-60*p);}}
 if(motion==='kneeExtension'){root=[0,.48,0];for(const s of ['l','r']){put(s+'Hip',-90);put(s+'Knee',90);}put(a+'Knee',90-70*p);}
 return {root,rotation,bones:r,legTargets};}

function clamTargets(side,p){const sign=side===0?1:-1,active=side===0?'l':'r';return ['l','r'].map(s=>{const hip=BONES.find(b=>b.id===s+'Hip').p,lower=s===active?sign*-.03:sign*-.08,ankle=[lower,.2,.04],sub=(a,b)=>a.map((x,i)=>x-b[i]),len=a=>Math.hypot(...a),scale=(a,v)=>a.map(x=>x*v),add=(a,b)=>a.map((x,i)=>x+b[i]),dot=(a,b)=>a.reduce((sum,x,i)=>sum+x*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],L1=len(sub(BONES.find(b=>b.id===s+'Knee').p,hip)),L2=len(sub(BONES.find(b=>b.id===s+'Ankle').p,BONES.find(b=>b.id===s+'Knee').p)),dist=len(sub(ankle,hip)),axis=scale(sub(ankle,hip),1/dist),along=(L1*L1-L2*L2+dist*dist)/(2*dist),radius=Math.sqrt(Math.max(0,L1*L1-along*along)),forward=[0,0,1],orth=sub(forward,scale(axis,dot(forward,axis))),unit=scale(orth,1/len(orth)),theta=s===active?-sign*rad(35)*p:0,around=add(scale(unit,Math.cos(theta)),scale(cross(axis,unit),Math.sin(theta))),knee=add(add(hip,scale(axis,along)),scale(around,radius));return {side:s,knee,ankle};});}
