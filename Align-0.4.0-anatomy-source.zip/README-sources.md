# Align 0.3 source notes

Clinical links and original exercise summaries: [exercise-data.mjs](exercise-data.mjs).

Adapted anatomical assets and generated previews: [attribution and licenses](anatomy/ATTRIBUTION.md).

Motion source: [anatomy-rig.mjs](anatomy-rig.mjs), [anatomy-skeleton.mjs](anatomy-skeleton.mjs), [anatomy-view.mjs](anatomy-view.mjs).

Preparation source: [prepare-anatomy.py](prepare-anatomy.py), requires numpy, DracoPy and fast-simplification. Set ALIGN_ANATOMY_INPUT to an existing input directory to prepare offline.

Third-party code: Three.js 0.180.0 (MIT), Draco (Apache-2.0), MediaPipe Tasks Vision 0.10.21 (Apache-2.0). Notices are included next to bundled files.

Animations and symptom-based options are educational and have not undergone clinical or physical Android-device validation.

## Align 0.4 gym examples
Wall press-ups and mini squats adapt NHS strength guidance. Biceps curls, lateral raises, seated band rows and seated knee extensions are original general fitness demonstrations with editable example doses, not source-prescribed rehabilitation programs. The anatomy reference informs muscle actions, not the chosen dose. All guided practice retains the symptom/clinician checks. Higher display resolution does not improve diagnostic validity.
