// Fit a sphere enclosing the entire movement to both dimensions of the viewport.
export function fitDistance(radius,verticalFov,aspect){const halfY=verticalFov*Math.PI/360,halfX=Math.atan(Math.tan(halfY)*Math.max(.01,aspect));return Math.max(.01,radius)/Math.sin(Math.min(halfY,halfX))*1.08;}
